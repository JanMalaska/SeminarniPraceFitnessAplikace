import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

class Aplikace():
    def __init__(self):
        self.width = 700
        self.height = 500
        self.uzel = tk.Tk()
        self.uzel.grid()
        self.uzel.columnconfigure(1,weight=1)
        self.uzel.columnconfigure(1,weight=1)
        self.prvninastaveni()
        self.main()
    def prvninastaveni(self):
        velikost_okna = str(f"{self.height}x{self.width}")
        self.uzel.resizable(0,0)
        self.uzel.geometry(velikost_okna)
    
    def vycisti(self):
        for widget in self.uzel.winfo_children():
            widget.grid_forget()
   
    def hlavnistranka(self):
        self.vycisti()
        self.uzel.title("Hlavní stránka")
        Napis = tk.Label(self.uzel, text="Vítej v hlavním menu",padx=10,pady=10)
        Napis.grid(column=1,row=1)    
        Sestroj = tk.Button(self.uzel,text="Sestroj plán",padx=5,pady=5,command= lambda:self.sestroj())        
        Sestroj.grid(column=1,row=3)

    
    def sestroj(self):
        self.vycisti()
        Nadpis = tk.Label(self.uzel,text="Zdajete informace pro sestrojení plánu",padx= 10,pady=10)
        Nadpis.grid(column=1,row=0)
        spacer1 = tk.Label(self.uzel,text="",)
        spacer1.grid(column=1,row=1)
        
        #vyber pohlavi
        pohlavinapis = tk.Label(self.uzel,text="Vyberte pohlaví",padx=10,pady=10) 
        pohlavinapis.grid(column=1,row=2)
        
        pohlavivar = tk.StringVar()
        pohlavi = ttk.Combobox(self.uzel,width=20,textvariable=pohlavivar)
        pohlavi['values']=("Muž","Žena")
        pohlavi.grid(column=1,row=3)
        
        spacer2 = tk.Label(self.uzel,text="").grid(column=1,row=4)
        #nastaveni vahy
        telesna_vaha = tk.IntVar()
        vaha_text = tk.Label(self.uzel,text="Zadejte vaši tělesnou váhu",padx=10,pady=10)
        vaha_vstup = tk.Entry(self.uzel)
        vaha_potvrzeni = tk.Button(self.uzel,text="Ok",command= lambda: self.ziskejvahu(vaha_vstup,telesna_vaha),padx=5,pady=5)
        
        vaha_text.grid(column=1,row=5)
        vaha_vstup.grid(column=1,row=6)
        vaha_potvrzeni.grid(column=1,row=7)
        
        spacer3 = tk.Label(self.uzel,text="").grid(column=1,row=8)
        #nastaveni zkusenosti
        zkusenosti_var = tk.StringVar()
        zkusenosti_text = tk.Label(self.uzel,text="Vyberte míru vašich zkušenosti",padx=10,pady=10)
        zkusenosti = ttk.Combobox(self.uzel,textvariable=zkusenosti_var)
        zkusenosti['values']=("Nováček","Začátečník","Pokročilý","Expert")

        zkusenosti_text.grid(column=1,row=9)
        zkusenosti.grid(column=1,row=10)

        spacer4 = tk.Label(self.uzel,text="").grid(column=1,row=11)
        #míra času na cvičení
        cas_var = tk.IntVar()
        cas_text = tk.Label(self.uzel,text="Nastavte míru času na cvičení ve dnech",pady=10,padx=10)
        cas_slider = tk.Scale(self.uzel,from_=1,to=7,orient="horizontal")
        cas_button = tk.Button(self.uzel,text="Ok",command= lambda: self.ZiskejCas(cas_slider,cas_var),padx=5,pady=5)


        cas_text.grid(column=1,row=12)
        cas_slider.grid(column=1,row=13)
        cas_button.grid(column=1,row=14)

        spacer5=tk.Label(self.uzel,text="").grid(column=1,row=15)
        #zjisteni míry vybavení subjektu
        vybaveni_var = tk.StringVar()
        vybaveni_text = tk.Label(self.uzel,text="Vyberte míru vašeho vybavení ke cvičení",padx=10,pady=10)
        vybaveni_vyber = ttk.Combobox(self.uzel,textvariable=vybaveni_var)
        vybaveni_vyber['values'] = ("Žádné","Základní","Pokročilé")
        
        vybaveni_text.grid(column=1,row=16)
        vybaveni_vyber.grid(column=1,row=17)

        spacer6=tk.Label(self.uzel,text="",pady=40).grid(column=1,row=18)
        #Další kroky
        zpet_button = tk.Button(self.uzel,text="Zpět",command= lambda:self.hlavnistranka())
        sestroj_button = tk.Button(self.uzel, text="Sestroj plán",command=lambda: self.overeniinformaci(pohlavivar,telesna_vaha,zkusenosti_var,cas_var,vybaveni_var))

        zpet_button.grid(column=0,row=19,padx=15)
        sestroj_button.grid(column=2,row=19,padx=15)

        # debug = tk.Button(self.uzel,text="dev",command=lambda:print(cas_var.get()))
        # debug.grid(column=1,row=20)
    
    def overeniinformaci(self,pohlavi,vaha,zkusenosti,cas,vybaveni):
        #ověření pohlaví
        try:
            if pohlavi.get() == "Muž":
                self._pohlavi = "M"
            elif pohlavi.get() == "Žena":
                self._pohlavi = "F"
            else:
                raise TypeError("špatné a nebo žádné pohlaví")
        except:
            messagebox.showerror("Nebylo vybráno pohlaví","Nevybrali jste pohlaví")
        
        #ověření váhy
        try:
            if vaha.get() == 0:
                raise TypeError("Není váha")
            else:
                self._vaha = vaha.get()
        except:
            messagebox.showerror("Nebyla zadána váha","Ujistěte se že jste zadali správně váhu a stisknuly tlačítko OK")

        #ověření zkušenosti
        try:
            zks = zkusenosti.get()
            if zks == "Nováček":
                self._zkusenosti = "N"
            elif zks == "Začátečník":
                self._zkusenosti = "Z"
            elif zks == "Pokročilý":
                self._zkusenosti = "P"
            elif zks == "Expert":
                self._zkusenosti = "E"
            else:
                raise ValueError("není zkusenosti")
        except:
            messagebox.showerror("Nebyly zadány zkušenosti","Ujistěte se že jste vybrali míru zkušeností")

        #ověření času
        try:
            if cas.get() == 0:
                raise ValueError("Nebyl zadán čas")
            else:
                self._cas = cas.get()
        except:
            messagebox.showerror("Nebyl zadán čas","Ujistěte se že jste si vybrali čas a potvrdili tlačítkem OK")

        #ověření vybavení

        try:
            if vybaveni.get() == "Žádné":
                self._vybaveni = 0
            elif vybaveni.get() == "Základní":
                self._vybaveni = 1
            elif vybaveni.get() == "Pokročilé":
                self._vybaveni = 2
            else:
                raise ValueError("Není vybavení")
        except:
            messagebox.showerror("Nebylo zadáné vybavení","Ujistěte se že jste vybrali míru vybavení")


            
    def ziskejvahu(self,pole,var):
        try:    
            vaha = int(pole.get())
            try:
                if vaha > 0:
                    var.set(pole.get())
                    print(pole.get())
            except:
                messagebox.showerror("Zadali jste špatný vstup",f"Byl zadán špatný vstup, vstup musí být kladné číslo.\n Váš vstup : {pole.get()} nesplňuje požadavky!")
        except:
            messagebox.showerror("Zadali jste špatný vstup",f"Byl zadán špatný vstup, vstup musí být kladné číslo.\n Váš vstup : {pole.get()} nesplňuje požadavky!")
    
    def ZiskejCas(self,slider,var):
        var.set(slider.get())
        print(slider.get())
        print(type(var.get()))
    
    def print(self,var):
        print(var.get())

    def debug(self):
        self.vycisti()
        self.uzel.title("Debug")
        Napis = tk.Label(self.uzel,text="1")
        Napis2 = tk.Label(self.uzel,text="2")
        Napis3 = tk.Label(self.uzel,text="3")
        Napis4 = tk.Label(self.uzel,text="4")
        Napis.grid(column=0,row=0)
        Napis2.grid(column=1,row=1)
        Napis3.grid(column=3,row=3)
        Napis4.grid(column=5,row=5)

    def main(self):
        self.hlavnistranka()
        self.uzel.mainloop()


program = Aplikace()
# program.main()