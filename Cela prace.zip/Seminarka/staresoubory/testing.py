# import tkinter as tk

# class Page(tk.Frame):
#     def __init__(self, parent, controller):
#         tk.Frame.__init__(self, parent)
#         self.controller = controller

#     def show(self):
#         self.lift()

# class MainPage(Page):
#     def __init__(self, parent, controller):
#         Page.__init__(self, parent, controller)
#         label = tk.Label(self, text="Main Page")
#         label.pack(pady=10, padx=10)
#         next_button = tk.Button(self, text="Next", command=lambda: controller.show_page(SecondPage))
#         next_button.pack()

# class SecondPage(Page):
#     def __init__(self, parent, controller):
#         Page.__init__(self, parent, controller)
#         label = tk.Label(self, text="Second Page")
#         label.pack(pady=10, padx=10)
#         back_button = tk.Button(self, text="Back", command=lambda: controller.show_page(MainPage))
#         back_button.pack()

# class SampleApp(tk.Tk):
#     def __init__(self, *args, **kwargs):
#         tk.Tk.__init__(self, *args, **kwargs)

#         container = tk.Frame(self)
#         container.pack(side="top", fill="both", expand=True)
#         container.grid_rowconfigure(0, weight=1)
#         container.grid_columnconfigure(0, weight=1)

#         self.pages = {}
#         for PageClass in (MainPage, SecondPage):
#             page = PageClass(container, self)
#             page.grid(row=0, column=0, sticky="nsew")
#             self.pages[PageClass] = page

#         self.show_page(MainPage)

#     def show_page(self, page):
#         self.pages[page].show()

# if __name__ == "__main__":
#     app = SampleApp()
#     app.mainloop()


class Soubory:
    def __init__(self):
        cviky = open("cviky.txt","r")
        cviky_cely_soubor = cvo
S = Soubory()