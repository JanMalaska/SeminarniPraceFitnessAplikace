# soubor = open("cviky.txt","r")
# seznam = (soubor.readlines())
# soubor.close()
# for x in range (0,seznam.__len__()):
#     print(seznam[x].replace("\n",""))

# radek = "2&R2&4&Cable Concentration Curl&https://exrx.net/WeightExercises/Brachialis/CBConcentrationCurl"
# radek_rozdeleny = radek.split("&")


seznam = [["kokot","rokot"],["plus"]]
print(seznam[0][1])