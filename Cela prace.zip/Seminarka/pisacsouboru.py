cviky = open("cviky.txt","a")
while True:
    vybavení = int(input("Vybavení (0,1,2) :"))
    část_svalu = input("Část svalu(R1,R2,P,Z,H,B,S,L,O) :")
    důležitost = int(input("Důležitost nejvic 5 nejmene 1 :"))
    název_cviku = input("Název cviku :")
    odkaz = input("odkaz na cvik :")
    návrh = (f"{vybavení}&{část_svalu}&{důležitost}&{název_cviku}&{odkaz}\n")
    print(návrh)
    potvrzeni = input("Správně? Enter ANO Cokoliv jine NE konec KONEC:")
    if potvrzeni == "":
        cviky.write(návrh)
    elif potvrzeni == "konec":
        break
cviky.close()