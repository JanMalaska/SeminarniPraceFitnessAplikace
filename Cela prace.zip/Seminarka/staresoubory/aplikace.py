import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

class Aplikace():
    def __init__(self):
        self.width = 700
        self.height = 500
        self.uzel = tk.Tk()
        self.uzel.grid()
        self.uzel.columnconfigure(1,weight=1)
        self.uzel.columnconfigure(1,weight=1)
        self.prvninastaveni()
        self.main()
        self.cviky = VytvareniPlanu()
        self.Soubory = Soubory()
    def prvninastaveni(self):
        velikost_okna = str(f"{self.height}x{self.width}")
        self.uzel.resizable(0,0)
        self.uzel.geometry(velikost_okna)
    
    def vycisti(self):
        for widget in self.uzel.winfo_children():
            widget.grid_forget()
   
    def hlavnistranka(self):
        self.vycisti()
        self.SchovatMenuBar()
        self.uzel.title("Hlavní stránka")
        Napis = tk.Label(self.uzel, text="Vítej v hlavním menu",padx=10,pady=10)
        Napis.grid(column=1,row=1)    
        Sestroj = tk.Button(self.uzel,text="Sestroj plán",padx=5,pady=5,command= lambda:self.sestroj())        
        Sestroj.grid(column=1,row=3)
        spacer=tk.Label(self.uzel,text="").grid(column=1,row=4)
        Nacist = tk.Button(self.uzel,text="Načíst",command=lambda:self.Nacist()).grid(column=1,row=5)
    
    def sestroj(self):
        self.vycisti()
        Nadpis = tk.Label(self.uzel,text="Zdajete informace pro sestrojení plánu",padx= 10,pady=10)
        Nadpis.grid(column=1,row=0)
        spacer1 = tk.Label(self.uzel,text="",)
        spacer1.grid(column=1,row=1)
        
        #vyber pohlavi
        pohlavinapis = tk.Label(self.uzel,text="Vyberte pohlaví",padx=10,pady=10) 
        pohlavinapis.grid(column=1,row=2)
        
        pohlavivar = tk.StringVar()
        pohlavi = ttk.Combobox(self.uzel,width=20,textvariable=pohlavivar)
        pohlavi['values']=("Muž","Žena")
        pohlavi.grid(column=1,row=3)
        
        spacer2 = tk.Label(self.uzel,text="").grid(column=1,row=4)
        #nastaveni vahy
        telesna_vaha = tk.IntVar()
        vaha_text = tk.Label(self.uzel,text="Zadejte vaši tělesnou váhu",padx=10,pady=10)
        vaha_vstup = tk.Entry(self.uzel)
        vaha_potvrzeni = tk.Button(self.uzel,text="Ok",command= lambda: self.ziskejvahu(vaha_vstup,telesna_vaha),padx=5,pady=5)
        
        vaha_text.grid(column=1,row=5)
        vaha_vstup.grid(column=1,row=6)
        vaha_potvrzeni.grid(column=1,row=7)
        
        spacer3 = tk.Label(self.uzel,text="").grid(column=1,row=8)
        #nastaveni zkusenosti
        zkusenosti_var = tk.StringVar()
        zkusenosti_text = tk.Label(self.uzel,text="Vyberte míru vašich zkušenosti",padx=10,pady=10)
        zkusenosti = ttk.Combobox(self.uzel,textvariable=zkusenosti_var)
        zkusenosti['values']=("Nováček","Začátečník","Pokročilý","Expert")

        zkusenosti_text.grid(column=1,row=9)
        zkusenosti.grid(column=1,row=10)

        spacer4 = tk.Label(self.uzel,text="").grid(column=1,row=11)
        #míra času na cvičení
        cas_var = tk.IntVar()
        cas_text = tk.Label(self.uzel,text="Nastavte míru času na cvičení ve dnech",pady=10,padx=10)
        cas_slider = tk.Scale(self.uzel,from_=1,to=5,orient="horizontal")
        cas_button = tk.Button(self.uzel,text="Ok",command= lambda: self.ZiskejCas(cas_slider,cas_var),padx=5,pady=5)


        cas_text.grid(column=1,row=12)
        cas_slider.grid(column=1,row=13)
        cas_button.grid(column=1,row=14)

        spacer5=tk.Label(self.uzel,text="").grid(column=1,row=15)
        #zjisteni míry vybavení subjektu
        vybaveni_var = tk.StringVar()
        vybaveni_text = tk.Label(self.uzel,text="Vyberte míru vašeho vybavení ke cvičení",padx=10,pady=10)
        vybaveni_vyber = ttk.Combobox(self.uzel,textvariable=vybaveni_var)
        vybaveni_vyber['values'] = ("Žádné","Základní","Pokročilé")
        
        vybaveni_text.grid(column=1,row=16)
        vybaveni_vyber.grid(column=1,row=17)

        spacer6=tk.Label(self.uzel,text="",pady=40).grid(column=1,row=18)
        #Další kroky
        zpet_button = tk.Button(self.uzel,text="Zpět",command= lambda:self.hlavnistranka())
        sestroj_button = tk.Button(self.uzel, text="Sestroj plán",command=lambda: self.overeniinformaci(pohlavivar,telesna_vaha,zkusenosti_var,cas_var,vybaveni_var))

        zpet_button.grid(column=0,row=19,padx=15)
        sestroj_button.grid(column=2,row=19,padx=15)

        # debug = tk.Button(self.uzel,text="dev",command=lambda:print(cas_var.get()))
        # debug.grid(column=1,row=20)
    
    def overeniinformaci(self,pohlavi,vaha,zkusenosti,cas,vybaveni):
        error = 0
        #ověření pohlaví
        try:
            if pohlavi.get() == "Muž":
                self._pohlavi = "M"
            elif pohlavi.get() == "Žena":
                self._pohlavi = "F"
            else:
                raise TypeError("špatné a nebo žádné pohlaví")
        except:
            error = 1
            print(f"chyba {error}")
            messagebox.showerror("Nebylo vybráno pohlaví","Nevybrali jste pohlaví")
        
        #ověření váhy
        try:
            if vaha.get() == 0:
                raise TypeError("Není váha")
            else:
                self._vaha = vaha.get()
        except:
            error = 1
            messagebox.showerror("Nebyla zadána váha","Ujistěte se že jste zadali správně váhu a stisknuly tlačítko OK")

        #ověření zkušenosti
        try:
            zks = zkusenosti.get()
            if zks == "Nováček":
                self._zkusenosti = "N"
            elif zks == "Začátečník":
                self._zkusenosti = "Z"
            elif zks == "Pokročilý":
                self._zkusenosti = "P"
            elif zks == "Expert":
                self._zkusenosti = "E"
            else:
                raise ValueError("není zkusenosti")
        except:
            error = 1
            print(f"chyba {error}")
            messagebox.showerror("Nebyly zadány zkušenosti","Ujistěte se že jste vybrali míru zkušeností")

        #ověření času
        try:
            if cas.get() == 0:
                raise ValueError("Nebyl zadán čas")
            else:
                self._cas = int(cas.get())
        except:
            error = 1
            print(f"chyba {error}")
            messagebox.showerror("Nebyl zadán čas","Ujistěte se že jste si vybrali čas a potvrdili tlačítkem OK")

        #ověření vybavení

        try:
            if vybaveni.get() == "Žádné":
                self._vybaveni = 0
            elif vybaveni.get() == "Základní":
                self._vybaveni = 1
            elif vybaveni.get() == "Pokročilé":
                self._vybaveni = 2
            else:
                raise ValueError("Není vybavení")
        except:
            error = 1
            print(f"chyba {error}")
            messagebox.showerror("Nebylo zadáné vybavení","Ujistěte se že jste vybrali míru vybavení")

        try:
            if error == 0:
                print("ok")
                self.vytvoreni()
        except:
            print(f"chyba konec {error}")
            messagebox.showerror("Nebyly zadány veškeré informace","Ujistěte se že jste zadali veškeré informace")

    def vytvoreni(self):
        cviky = VytvareniPlanu()
        cas = self._cas
        vybaveni = self._vybaveni
        cviky.VyberDoDnu(cas,vybaveni)
        # self.cviky.VyberDoDnu(cas,vybaveni)
        self.den1list = cviky.Den1list
        self.den2list = cviky.Den2list
        self.den3list = cviky.Den3list
        self.den4list = cviky.Den4list
        self.den5list = cviky.Den5list
        # print(self.den1list)
        # print(self.den2list)
        # print(self.den3list)
        # print(self.den4list)
        # print(self.den5list)
        self.dnylist = list()
        self.dnylist.append(self.den1list)
        self.dnylist.append(self.den2list)
        self.dnylist.append(self.den3list)
        self.dnylist.append(self.den4list)
        self.dnylist.append(self.den5list)
        
        
        
        # print(self.den1list)
        
        self.den1()
    
    
    def den1(self):
        self.vycisti()
        cviky = VytvareniPlanu()
        # print(cviky.VratitSeznamSNazvy(den1listik))
        self.MenuBar()
        self.VytvorDen(1,cviky.VratitSeznamSNazvy(self.den1list),cviky.VratitSeznamSOdkazy(self.den1list))
    
    def den2(self):
        self.vycisti()
        cviky=VytvareniPlanu()
        self.VytvorDen(1,cviky.VratitSeznamSNazvy(self.den2list),cviky.VratitSeznamSOdkazy(self.den2list))
    
    def den3(self):
        self.vycisti()
        cviky = VytvareniPlanu()
        self.VytvorDen(1,cviky.VratitSeznamSNazvy(self.den3list),cviky.VratitSeznamSOdkazy(self.den3list))
    
    def den4(self):
        self.vycisti()
        cviky = VytvareniPlanu()
        self.VytvorDen(1, cviky.VratitSeznamSNazvy(self.den4list), cviky.VratitSeznamSOdkazy(self.den4list))
    
    def den5(self):
        self.vycisti()
        cviky = VytvareniPlanu()
        self.VytvorDen(1, cviky.VratitSeznamSNazvy(self.den5list), cviky.VratitSeznamSOdkazy(self.den5list))


    def VytvorDen(self,startingrow:int,SeznamDneNazvy:list,SeznamDneOdkazy:list):
        self.vycisti()
        cviky = VytvareniPlanu()
        radek = startingrow
        for x in range(0,SeznamDneNazvy.__len__()):
            space = tk.Label(self.uzel,text="").grid(column=0,row=radek)
            radek += 1
            Cvik = tk.Label(self.uzel,text=SeznamDneNazvy[x])
            # Odkaz = tk.Button(self.uzel,text="Otevřít web",command=lambda:self.Web(SeznamDneOdkazy[x])) 
            # Odkaz.grid(column=1,row = radek)
            odkaz = tk.Label(self.uzel,text=SeznamDneOdkazy[x])
            Cvik.grid(column=1,row=radek)
            radek +=1
            odkaz.grid(column=1,row = radek)
            radek +=1
   
    
    
    
    def Web(self,url):
        import webbrowser
        webbrowser.open(url,1)
    
    
    
    def MenuBar(self):
        menu = tk.Menu(self.uzel)
        self.uzel.config(menu=menu)
        Soubor = tk.Menu(menu)
        menu.add_cascade(label="Soubor",menu=Soubor)
        Soubor.add_command(label="Hlavní menu",command=lambda:self.hlavnistranka())
        Soubor.add_command(label="Uložit",command=lambda: self.Ulozit())
        Soubor.add_command(label="Načíst",command=lambda: self.Nacteni())
        Dny = tk.Menu(menu)
        menu.add_cascade(label="Dny",menu=Dny)
        Dny.add_command(label="Den 1",command=lambda:self.den1())
        Dny.add_command(label="Den 2",command=lambda:self.den2())
        Dny.add_command(label="Den 3",command=lambda:self.den3())
        Dny.add_command(label="Den 4",command=lambda:self.den4())
        Dny.add_command(label="Den 5",command=lambda:self.den5())   
    def SchovatMenuBar(self):
        self.uzel.config(menu="")
    
    def ziskejvahu(self,pole,var):
        try:    
            vaha = int(pole.get())
            try:
                if vaha > 0:
                    var.set(pole.get())
                    print(pole.get())
            except:
                messagebox.showerror("Zadali jste špatný vstup",f"Byl zadán špatný vstup, vstup musí být kladné číslo.\n Váš vstup : {pole.get()} nesplňuje požadavky!")
        except:
            messagebox.showerror("Zadali jste špatný vstup",f"Byl zadán špatný vstup, vstup musí být kladné číslo.\n Váš vstup : {pole.get()} nesplňuje požadavky!")
    
    def ZiskejCas(self,slider,var):
        var.set(slider.get())
        print(slider.get())
        print(type(var.get()))
    
    def print(self,var):
        print(var.get())

    def debug(self):
        self.vycisti()
        self.uzel.title("Debug")
        Napis = tk.Label(self.uzel,text="1")
        Napis2 = tk.Label(self.uzel,text="2")
        Napis3 = tk.Label(self.uzel,text="3")
        Napis4 = tk.Label(self.uzel,text="4")
        Napis.grid(column=0,row=0)
        Napis2.grid(column=1,row=1)
        Napis3.grid(column=3,row=3)
        Napis4.grid(column=5,row=5)

    def Ulozit(self):
        sb = Soubory
        self.vycisti()
        self.SchovatMenuBar()
        Ulozit1 = tk.Button(self.uzel,text="Pozice 1",command=lambda:sb.Ulozit(sb,1,self.dnylist))
        Ulozit1.grid(column=1,row=1)
        space1 = tk.Label(self.uzel,text="").grid(column=1,row=2)
        Ulozit2 = tk.Button(self.uzel,text = "Pozice 2",command=lambda:sb.Ulozit(sb,2,self.dnylist))
        Ulozit2.grid(column=1,row=3)

        space2 = tk.Label(self.uzel,text="").grid(column=1,row=2)
        Ulozit2 = tk.Button(self.uzel,text = "Pozice 2",command=lambda:sb.Ulozit(sb,2,self.dnylist))
        Ulozit2.grid(column=1,row=3)
    
        space3 = tk.Label(self.uzel,text="").grid(column=1,row=4)
        Ulozit3 = tk.Button(self.uzel,text = "Pozice 3",command=lambda:sb.Ulozit(sb,3,self.dnylist))
        Ulozit3.grid(column=1,row=5) 

        space4 = tk.Label(self.uzel,text="").grid(column=1,row=6)
        Ulozit4 = tk.Button(self.uzel,text = "Pozice 4",command=lambda:sb.Ulozit(sb,4,self.dnylist))
        Ulozit4.grid(column=1,row=7)    
    
        space5 = tk.Label(self.uzel,text="").grid(column=1,row=8)
        Ulozit5 = tk.Button(self.uzel,text = "Pozice 5",command=lambda:sb.Ulozit(sb,5,self.dnylist))
        Ulozit5.grid(column=1,row=9)
    
        space6 = tk.Label(self.uzel,text="").grid(column=1,row=10)
        hlavnimenu = tk.Button(self.uzel,text="Zpět do hlavního menu",command=lambda:self.hlavnistranka()).grid(column=1,row=11)
    
    def Nacist(self):
        self.vycisti()
        self.SchovatMenuBar()
        sb = Soubory()
        Nacist1 = tk.Button(self.uzel,text="Pozice 1",command=lambda:sb.Nacist(1)).grid(column=1,row=1)

    def main(self):
        self.hlavnistranka()
        self.uzel.mainloop()


class Soubory:
    def __init__(self):
        self.radkynactene = list()
        cviky = open("cviky.txt","r")
        self.nactenidoseznamu(cviky)
        cviky.close() 
    def nactenidoseznamu(self,soubor):
        vsechnyradky = soubor.readlines()
        for x in range (0,vsechnyradky.__len__()):
            radek = vsechnyradky[x]
            upravenyradek = radek.replace("\n","")
            self.radkynactene.append(upravenyradek)
            # print(upravenyradek)
    def odevzdaniseznamu(self):
        return self.radkynactene
    def Ulozit(self,pozice_ukladani,seznam_seznamu):

        if pozice_ukladani ==1:
            soubor = open("ulozeni1.txt","w")
            string = str(seznam_seznamu)

            string = string.replace("], [","]\n[")
            string = string.replace("[[","[")
            string = string.replace("]]","]")

            print(string)
            soubor.write(string)
            soubor.close()
        if pozice_ukladani ==2:
            soubor = open("ulozeni2.txt","w")
            string = str(seznam_seznamu)

            string = string.replace("], [","]\n[")
            string = string.replace("[[","[")
            string = string.replace("]]","]")

            print(string)
            soubor.write(string)
            soubor.close()
        if pozice_ukladani ==3:
            soubor = open("ulozeni3.txt","w")
            string = str(seznam_seznamu)

            string = string.replace("], [","]\n[")
            string = string.replace("[[","[")
            string = string.replace("]]","]")

            print(string)
            soubor.write(string)
            soubor.close()
        if pozice_ukladani ==4:
            soubor = open("ulozeni4.txt","w")
            string = str(seznam_seznamu)

            string = string.replace("], [","]\n[")
            string = string.replace("[[","[")
            string = string.replace("]]","]")

            print(string)
            soubor.write(string)
            soubor.close()
        if pozice_ukladani ==5:
            soubor = open("ulozeni5.txt","w")
            string = str(seznam_seznamu)

            string = string.replace("], [","]\n[")
            string = string.replace("[[","[")
            string = string.replace("]]","]")

            print(string)
            soubor.write(string)
            soubor.close()

    def Nacist(self,pozice):
        if pozice == 1:
            soubor = open("ulozeni1.txt","r")
            nactene_radky = soubor.readline()
            
            nactene_radky = nactene_radky.replace("[[","[")
            nactene_radky = nactene_radky.replace("]]","]")
            nactene_radky = nactene_radky.replace("][","],[")

            print(nactene_radky)
            listzradku = nactene_radky.split("],[")
            print(listzradku)
            soubor.close()




class VytvareniPlanu():
    def __init__(self):
        soubor = Soubory()
        self.Rawlist = soubor.odevzdaniseznamu()
        self.Vybavenilist = list()
        self.Skupinalist = list()
        self.Potrebalist = list()
        self.Nazevlist = list()
        self.Odkazlist = list()
        self.RozdeleniDoSeznamu()
        self.PrideleniDoNaciniSkupiny()
        # self.DevPrint()
    def RozdeleniDoSeznamu(self):
        for x in range (0,self.Rawlist.__len__()):
            radek = self.Rawlist[x]
            kousky = radek.split("&")
            self.Vybavenilist.append(int(kousky[0]))
            self.Skupinalist.append(kousky[1])
            self.Potrebalist.append(int(kousky[2]))
            self.Nazevlist.append(kousky[3])
            self.Odkazlist.append(kousky[4])
    
    def PrideleniDoNaciniSkupiny(self):
       self.Vybaveni0jmeno = list()
       self.Vybaveni0skupina = list()
       self.Vybaveni1jmeno = list()
       self.Vybaveni1skupina = list()
       self.Vybaveni2jmeno = list()
       self.Vybaveni2skupina = list()
       for x in range (0,self.Vybavenilist.__len__()):
            miravybaveni = self.Vybavenilist[x]
            if miravybaveni == 0:
               self.Vybaveni0jmeno.append(self.Nazevlist[x])
               self.Vybaveni0skupina.append(self.Skupinalist[x])
            elif miravybaveni == 1:
                self.Vybaveni1jmeno.append(self.Nazevlist[x])
                self.Vybaveni1skupina.append(self.Skupinalist[x])
            elif miravybaveni == 2:
               self.Vybaveni2jmeno.append(self.Nazevlist[x])
               self.Vybaveni2skupina.append(self.Skupinalist[x])
    
    
    def VyberDoDnu(self,PocetDnu:int,UrovenVybaveni:int):
        import random
        print("hello")
        if UrovenVybaveni == 0:
            NazvyCviku = self.Vybaveni0jmeno
            SkupinaCviku = self.Vybaveni0skupina
        elif UrovenVybaveni == 1:
            NazvyCviku = self.Vybaveni1jmeno
            SkupinaCviku = self.Vybaveni1skupina
        elif UrovenVybaveni==2:
            NazvyCviku = self.Vybaveni2jmeno
            SkupinaCviku = self.Vybaveni2skupina

        self.Den1list=list()
        self.Den2list=list()
        self.Den3list=list()
        self.Den4list=list()
        self.Den5list=list()
        if PocetDnu == 1:
            potreba_list = ["R1","R2","P","Z","H","B","S","L"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den1list.append(self.Nazevlist.index(cvik))
                            self.Den1list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            # for x in range (0,self.Den1list.__len__()):
            #     print(self.Nazevlist[self.Den1list[x]])
        if PocetDnu == 2:
            potreba_list = ["R1","R2","P","Z","H"] 
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den1list.append(self.Nazevlist.index(cvik))
                            self.Den1list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["B","S","L","O"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den2list.append(self.Nazevlist.index(cvik))
                            self.Den2list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
        if PocetDnu == 3:
            potreba_list = ["R2","P","Z","Z"] 
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den1list.append(self.Nazevlist.index(cvik))
                            self.Den1list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["R1","R1","H","H"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den2list.append(self.Nazevlist.index(cvik))
                            self.Den2list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["S","L","B","O"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den3list.append(self.Nazevlist.index(cvik))
                            self.Den3list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
        if PocetDnu == 4:
            potreba_list = ["R2","R2","P","Z","Z"] 
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den1list.append(self.Nazevlist.index(cvik))
                            self.Den1list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["R1","R1","H","H"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den2list.append(self.Nazevlist.index(cvik))
                            self.Den2list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["S","L","B"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den3list.append(self.Nazevlist.index(cvik))
                            self.Den3list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["O"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den4list.append(self.Nazevlist.index(cvik))
                            self.Den4list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
    
        if PocetDnu == 5:
            potreba_list = ["R2","R2","P","Z","Z"] 
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den1list.append(self.Nazevlist.index(cvik))
                            self.Den1list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["S","L","B"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den2list.append(self.Nazevlist.index(cvik))
                            self.Den2list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["O"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den3list.append(self.Nazevlist.index(cvik))
                            self.Den3list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["R1","R1","H","H"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den4list.append(self.Nazevlist.index(cvik))
                            self.Den4list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
            potreba_list = ["S","S","S","B"]
            while potreba_list.__len__() > 0:
                    try:
                        vyber_cviku = random.randint(0,NazvyCviku.__len__())
                        cvik = NazvyCviku[vyber_cviku]
                        skupina = SkupinaCviku[vyber_cviku]
                        if skupina in potreba_list:
                            self.Den5list.append(self.Nazevlist.index(cvik))
                            self.Den5list.sort()
                            potreba_list.remove(skupina)   
                    except:
                        pass
    def VratitSeznamSNazvy(self,seznam:list):
        sezanamnavraceni = []
        for x in range(0,seznam.__len__()):
            sezanamnavraceni.append(self.Nazevlist[seznam[x]])
        return sezanamnavraceni 
    def VratitSeznamSOdkazy(self,seznam:list):
        seznamnavraceni = list()
        for x in range(0,seznam.__len__()):
            seznamnavraceni.append(self.Odkazlist[seznam[x]])
        return seznamnavraceni
    def DevPrint(self):
        print(self.Vybaveni0jmeno)
        print(self.Vybaveni0skupina)       



# s = Soubory()
# c = VytvareniPlanu()
# print(c.Vybaveni0jmeno)
# import random 
# cislo = random.randint(1,c.Vybaveni0jmeno.__len__())
# slovo = c.Vybaveni0jmeno[cislo]
# print (slovo)
# slovo2 = c.Nazevlist.index(slovo)
# slovo2 = c.Nazevlist[slovo2]
# print(slovo2)
# c.VyberDoDnu(4,0)
# print(c.VratitSeznamSNazvy([0, 11, 25, 33, 42, 51, 61, 69]))
program = Aplikace()
# program.main()