from tkinter import *
from tkinter import ttk

root = Tk(screenName="Trénovací Kamarádík")
frm = ttk.Frame(root, padding=10)
frm.grid()
ttk.Label(frm, text="Tady to bude hodně v prdeli").grid(column=0,row=0)
ttk.Button(frm,text="Timto se to ukončí(můk život)",command=root.destroy).grid(column=0,row=1)

new = ttk.Frame(root,padding=10)
new.grid()


root.mainloop()

# class Main():
#     def __init__(self):
