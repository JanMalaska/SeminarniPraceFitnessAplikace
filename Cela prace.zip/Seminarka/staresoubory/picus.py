import tkinter as tk
from tkinter import filedialog, messagebox

def save_file():
    # Open the save file dialog
    file_path = filedialog.asksaveasfilename(
        initialdir="/", 
        title="Save as", 
        defaultextension=".txt",
        filetypes=(("Text files", "*.txt"), ("All files", "*.*"))
    )
    
    # Check if a file name was provided
    if file_path:
        try:
            # Open the file for writing
            with open(file_path, "w") as file:
                # Write data to the file
                file.write("This is a sample text.")
                messagebox.showinfo("Success", "File saved successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while saving the file: {e}")
    else:
        messagebox.showwarning("Cancelled", "Save operation was cancelled.")

# Create the main application window
root = tk.Tk()
root.title("Save File Example")

# Create a button to trigger the save file dialog
save_button = tk.Button(root, text="Save File", command=save_file)
save_button.pack(pady=20)

# Run the application
root.mainloop()
