import tkinter as tk

class Aplikace():
    def __init__(self):
        self.width = 700
        self.height = 400
        self.uzel = tk.Tk()
        self.uzel.grid()
        self.uzel.columnconfigure(0,weight=0)
        self.uzel.columnconfigure(1,weight=3)
        self.prvninastaveni()
    
    def prvninastaveni(self):
        velikost_okna = str(f"{self.height}x{self.width}")
        self.uzel.resizable(0,0)
        self.uzel.geometry(velikost_okna)
    
    def vycisti(self):
        for widget in self.uzel.winfo_children():
            widget.grid_forget()
   
    def hlavnistranka(self):
        self.uzel.title("Hlavní stránka")
        Napis = tk.Label(self.uzel, text="Vítej v hlavním menu")
        Napis.grid(column=1,row=1)    
        dalsi = tk.Button(self.uzel,text="Další stránka",padx=5,pady=5,command= lambda: self.setupplanu())
        dalsi.grid(column=2,row=9)
    
    def setupplanu(self):
        self.vycisti()
        self.uzel.title("Sestavení plánu")
        Napis = tk.Label(self.uzel,text="nastavte si plán",padx=1,pady=1)
        Napis.grid(column=1,row=1)

    def main(self):
        self.hlavnistranka()
        self.uzel.mainloop()

program = Aplikace()
program.main()