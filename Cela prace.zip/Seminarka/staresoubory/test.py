# # import tkinter as tk
 
# # window = tk.Tk()
# # window.title("Grid Manager")
 
# # for x in range(2):
# #    window.columnconfigure(x, weight=1, minsize=100)
# #    window.rowconfigure(x, weight=1, minsize=75)
# #    for y in range(2):
# #        frame = tk.Frame(
# #            master=window,
# #            relief=tk.RAISED,
# #            borderwidth=1
# #        )
# #        frame.grid(row=x, column=y, padx=10, pady=10)  # line 13
# #        label = tk.Label(master=frame, text=f"row {x}ncolumn {y}")
# #        label.pack()
 
# # window.mainloop()
# from tkinter import (Tk, ttk, Label, Frame, Button,
#     Checkbutton, Radiobutton, IntVar, HORIZONTAL)

# class  SimpleGUI(Tk):

#     def __init__(self):
#         super().__init__()
#         self.initializeUI()

#     def initializeUI(self):
#         self.title("Food Order Form")
#         self.minsize(300, 200)  # width, height
#         self.geometry("400x350+50+50")
#         self.setupWindow()

#     def setupWindow(self):
#         """ Set up the widgets."""
#         title = Label(self, text="Food Order Form",
#             font=('Helvetica', 20), bd=10)
#         title.pack()

#         line = ttk.Separator(self, orient=HORIZONTAL)
#         line.pack(fill='x')

#         order_label = Label(self, text="What would you like to order?", bd=10)
#         order_label.pack(anchor='w')

#         foods_list = ["Sandwich", "Salad", "Soup", "Pizza"]
#         self.foods_dict = {}

#         # Populate the dictionary with checkbutton widgets
#         for  i, food_item in  enumerate(foods_list):

#             # Set the text for each checkbutton
#             self.foods_dict[food_item] = Checkbutton(self, text=food_item)

#             # Create a new instance of IntVar() for each checkbutton
#             self.foods_dict[food_item].var = IntVar()

#             # Set the variable parameter of the checkbutton
#             self.foods_dict[food_item]['variable'] = self.foods_dict[food_item].var

#             # Arrange the checkbutton in the window
#             self.foods_dict[food_item].pack(anchor='w')

#         payment_label = Label(self, text="How do you want to pay?", bd=10)
#         payment_label.pack(anchor='w')

#         # Create integer variable
#         self.var = IntVar()
#         self.var.set(0)  # Use set() initialize the variable
#         self.payment_methods = ["PayPal", "Credit Card", "Other"]

#         for  i, method in  enumerate(self.payment_methods):
#             self.pymt_method = Radiobutton(self, text=method, variable=self.var, value=i)
#             self.pymt_method.pack(anchor='w')

#         # Use ttk to add styling to button
#         style = ttk.Style()
#         style.configure('TButton', bg='skyblue', fg='white')

#         # Create button that will call the method to display text and
#         # close the program
#         next_button = ttk.Button(self, text="Next", command=self.printResults)
#         next_button.pack()

#     def printResults(self):
#         """Print the results of the checkboxes and radio buttons."""
#         for  cb in  self.foods_dict.values():
#             if  cb.var.get():
#                 print('Item selected: {}'.format(cb['text']))

#         index = self.var.get()
#         print("Payment method: {}".format(self.payment_methods[index]))
#         self.quit()

# if  __name__  ==  "__main__":
#     app = SimpleGUI()
#     app.mainloop()

# string = '["kokot","velky"]'
# list = list(string)
# print(list)








        nactene_radky = soubor.readline()
        nactene_radky = nactene_radky.replace("[[","")
        nactene_radky = nactene_radky.replace("]]","")
        nactene_radky_list = nactene_radky.split("], [")
        for x in range(0,nactene_radky_list.__len__()):
            jeden_den = nactene_radky_list[x]
            if x == 0:
                den1int = list()
                den1 = jeden_den.split(",")
                for x in range(0,den1.__len__()):
                    strcislo = int(den1[x])
                    den1int.append(strcislo)
            if x == 1:
                den2int = list()
                den2 = jeden_den.split(",")
                for x in range(0,den2.__len__()):
                    strcislo = int(den2[x])
                    den2int.append(strcislo)                    
            if x == 2:
                den3int = list()
                den3 = jeden_den.split(",")
                for x in range(0,den3.__len__()):
                    strcislo = int(den3[x])
                    den3int.append(strcislo)                    
            if x == 3:
                den4int = list()
                den4 = jeden_den.split(",")
                for x in range(0,den4.__len__()):
                    strcislo = int(den4[x])
                    den4int.append(strcislo)                    
            if x == 4:
                den5int = list()
                den5 = jeden_den.split(",")
                for x in range(0,den5.__len__()):
                    strcislo = int(den5[x])
                    den5int.append(strcislo)         
    except:
        messagebox.showerror("Něco se nepovedlo","Soubor se nepovedlo otevrit")